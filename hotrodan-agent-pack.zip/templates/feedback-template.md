# Feedback (agent → manager)

- Agent: <name>
- Sprint: <YYYY-MM-DD>
- What I just finished:
  - ...
- What I propose next (ranked):
  1) <proposal, impact, est>
  2) ...
- What I need (from other agents or credentials):
  - <need> → blocked by <agent/secret>
- Risks/observations:
  - ...
- Suggested changes to RPG (optional):
  - JSON Patch-ish: [{ "op": "add|replace|remove", "path": "/nodes/…", "value": … }]
